#include <iostream>
using namespace std;

class Student {
protected:
    std::string name;
    int age;

public:
    Student(std::string name, int age) : name(name), age(age) {}

    void setName(std::string newName) {
        name = newName;
    }

    std::string getName() const {
        return name;
    }

    void setAge(int newAge) {
        age = newAge;
    }

    int getAge() const {
        return age;
    }

    void printInfo() const {
    cout << "Name: " << name <<endl;
	cout<<"Age: " << age <<endl;
    }
};

class GraduateStudent : public Student {
private:
    string level;
    int year;

public:
    GraduateStudent(std::string name, int age, std::string level, int year)
        : Student(name, age), level(level), year(year) {}

    void setLevel(std::string newLevel) {
        level = newLevel;
    }

   string getLevel() const {
      return level;
    }

    void setYear(int newYear) {
        year = newYear;
    }

    int getYear() const {
        return year;
    }

    void printInfo() const {
        Student::printInfo();
    cout <<"Level: " << level<<endl;
	cout<<"Year: " << year<<endl;
    }
};

int main() {
    GraduateStudent graduateStudent("Umair tariq", 25, "BSc", 2);
    graduateStudent.printInfo();

    return 0;
}
