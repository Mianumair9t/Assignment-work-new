#include <iostream>
#include <string>

class Student {
protected:
    std::string name;
    int age;

public:
    Student(std::string name, int age) : name(name), age(age) {}

    void printInfo() const {
        std::cout << "Name: " << name << ", Age: " << age << std::endl;
    }
};

class Master : public Student {
private:
    std::string level;
    int year;
    int newid;

public:
    Master(std::string name, int age, std::string level, int year, int newid)
        : Student(name, age), level(level), year(year), newid(newid) {}

    void printInfo() const {
        Student::printInfo();
        std::cout << "Level: " << level << ", Year: " << year
                  << ", New ID: " << newid << std::endl;
    }
};

int main() {
    Student student1("Umair tariq", 19);
    std::cout << "Student Information:" << std::endl;
    student1.printInfo();
    std::cout << std::endl;

    Master myInfo("Sir sajjad", 25, "Master's", 2, 12345);
    std::cout << "Master Information:" << std::endl;
    myInfo.printInfo();

    return 0;
}
