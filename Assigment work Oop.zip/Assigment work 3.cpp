#include <iostream>
using namespace std;

class GraduateStudent {
protected:
    std::string name;
    int age;
    std::string level;
    int year;

public:
    GraduateStudent(std::string name, int age, std::string level, int year)
        : name(name), age(age), level(level), year(year) {}

    void printInfo() const {
    cout << "Name: "<<name<<endl;
	cout<<"Age: "<< age<<endl;
    cout<<"Level: "<< level<<endl;
	cout<<"Year: "<<year<<endl;
    }
};

class Master : public GraduateStudent {
private:
    int newid;

public:
    Master(std::string name, int age, std::string level, int year, int newid)
        : GraduateStudent(name, age, level, year), newid(newid) {}

    void setNewId(int id) {
        newid = id;
    }

    int getNewId() const {
        return newid;
    }

    void printInfo() const {
        GraduateStudent::printInfo();
        std::cout << "New ID: " << newid << std::endl;
    }
};

int main() {
    Master masterStudent("Umair tariq", 19, "BSc", 2, 12345);
    masterStudent.printInfo();

    return 0;
}
