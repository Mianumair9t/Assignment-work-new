#include <iostream>
using namespace std;

class Student {
private:
    int studentNumber;
    std::string studentName;
    double studentAverage;

public:
    Student() : studentNumber(0), studentName(""), studentAverage(0.0) {}

    void setStudentNumber(int number) {
        studentNumber = number;
    }

    int getStudentNumber() const {
        return studentNumber;
    }

    void setStudentName(const std::string& name) {
        studentName = name;
    }

    const std::string& getStudentName() const {
        return studentName;
    }

    void setStudentAverage(double average) {
        studentAverage = average;
    }

    double getStudentAverage() const {
        return studentAverage;
    }

    void printStudentInfo() const {
        std::cout << "Student Number: " << studentNumber << std::endl;
        std::cout << "Student Name: " << studentName << std::endl;
        std::cout << "Student Average: " << studentAverage << std::endl;
    }
};

// Example usage:
int main() {
    Student student1;
    student1.setStudentNumber(76);
    student1.setStudentName("Umair tariq");
    student1.setStudentAverage(90.5);
    student1.printStudentInfo();

    return 0;
}
